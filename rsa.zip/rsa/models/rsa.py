from odoo import models, fields, api, _
from datetime import date
import geocoder
from haversine import haversine


class CustomerInfo(models.Model):
    _name = "customer.info"
    _description = "Customer Information"

    # Fields
    name = fields.Char(readonly=True)
    customer_name = fields.Char(string="Customer Name", required=True)
    email = fields.Char(string="E-mail")
    customer_contact = fields.Integer(string="Customer Contact", size=10, required=True)
    emergency_contact = fields.Integer(string="Emergency Contact", size=10)
    address = fields.Text(string="Address")
    customer_role = fields.Selection([('customer', 'Customer'), ('service_man', 'Service Man')])
    driving_license_id = fields.Char(string="Driving License _id")

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('customer.info') or '/'
        return super(CustomerInfo, self).create(vals)


class ServiceStation(models.Model):
    _name = "service.station"
    _description = "Service Station Information"

    # Fields
    name = fields.Char(readonly=True)
    station_name = fields.Char(string="Service Station Name", required=True)
    station_contact = fields.Integer(string="Service Station Contact", size=10, required=True)
    station_address = fields.Text(string="Service Station Address", required=True)
    station_longitude = fields.Float(string="Longitude of Service Station", required=True, digits=(12,6))
    station_latitude = fields.Float(string="Latitude of Service Station", required=True, digits=(12,6))

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('service.station') or '/'
        return super(ServiceStation, self).create(vals)


class VehicleInfo(models.Model):
    _name = "vehicle.info"
    _description = "Vehicle Information"

    # Fields
    name = fields.Char(readonly=True)
    vehicle_registration = fields.Char(string="Vehicle Registration No.", required=True)
    vehicle_company = fields.Char(string="Vehicle Company", required=True)
    vehicle_series = fields.Char(string="Car Model or Series", required=True)
    damage = fields.Boolean(string="If any Accidents or Damage", required=True)
    last_service_date = fields.Date(string="Last Service Date")
    last_service_station = fields.Char(string="Last Place of service")

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('vehicle.info') or '/'
        return super(VehicleInfo, self).create(vals)


class UserLocation(models.Model):
    _name = "user.location"
    _description = "User's Current Location'"

    # Fields
    name = fields.Char(string="Location _id", required=True)
    service_request_id = fields.Many2one('service.request', string="Service Request Id")
    customer_id = fields.Many2one('customer.info', string="Customer Id")
    user_latitude = fields.Float(string="Latitude of User's Current Location", required=True, digits=(12,6))
    user_longitude = fields.Float(string="Longitude of User's Current Location", required=True, digits=(12,6))


class ServiceRequest(models.Model):
    _name = "service.request"
    _description = "Breakdown Service Request"

    # Fields
    name = fields.Char(readonly=True)
    customer_id = fields.Many2one('customer.info', string="Customer Id")
    customer_name = fields.Char('Customer Name')
    customer_contact = fields.Integer('Customer Contact', size=10)
    customer_email = fields.Char('E-mail')
    vehicle_company = fields.Char('Company Name')
    vehicle_model = fields.Char('Vehicle Model')
    vehicle_registration_id = fields.Many2one('vehicle.info', string="Vehicle Registration Id")
    service_station_id = fields.Many2one('service.station', string="Service Station Id")
    breakdown_description = fields.Text(string="Breakdown Description")
    breakdown_location = fields.Many2one('user.location', string="Breakdown Location")
    latitude = fields.Float(readonly=True, digits=(12,6))
    longitude = fields.Float(readonly=True, digits=(12,6))

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('service.request') or '/'
        result = super(ServiceRequest, self).create(vals)
        self.env['service.history'].create(
            {
                "service_request_id": result.id,
                "customer_id": result.customer_id.id,
                "vehicle_registration_id": result.vehicle_registration_id.id,
                "service_station_id": result.service_station_id.id
            }
        )
        return result

    def get_location(self):
        g = geocoder.ip('me')
        self.latitude = g.lat
        self.longitude = g.lng

    def get_service_station(self):
        service_station_obj = self.env['service.station']

        customer_location = (self.longitude, self.latitude)
        station_fields = service_station_obj.fields_get()
        print('\n\nGGGGGGGGGGGGGGGGGGGGG',station_fields['station_longitude'])

        print('\n\nGGGGGGGGGGGGGGGGGGGGG',service_station_obj['station_longitude'])



class ServiceHistory(models.Model):
    _name = "service.history"
    _description = "Application Usage History"

    # Fields
    service_request_id = fields.Many2one('service.request', string="Service Request Id")
    customer_id = fields.Many2one('customer.info', string="Customer Id")
    vehicle_registration_id = fields.Many2one('vehicle.info', string="Vehicle Registration Id")
    service_station_id = fields.Many2one('service.station', string="Service Station Id")
    date = fields.Date(string="Date", default=date.today())
