{
    "name": "Road Side Assistant",
    "description": "Road Side Assistant",
    "author": "Darshit Dudhwala",
    "data": [
        'security/user_group.xml',
        'security/ir.model.access.csv',
        'views/rsa_person_info_view.xml',
        'views/rsa_service_request_view.xml',
        'views/rsa_service_station_view.xml',
        # 'views/rsa_website_crm.xml',
        # 'views/rsa_website_crm_data.xml',
    ],
    "application": True,
    "installable": True,
}