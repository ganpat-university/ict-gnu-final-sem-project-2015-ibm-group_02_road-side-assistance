from odoo import http
from odoo.http import request

class WebsiteRegistration(http.Controller):
    @http.route(['/odoo-registration'], type='http', auth="public", website=True)
    def odooregistration(self, **kw):

        values = {}
        for field_name, field_value in kw.items():
            values[field_name] = field_value
        if values:
            crm_id = request.env['crm.lead'].sudo().create(values)
            if crm_id:
                return request.render('website_crm.contactus_thanks')

        return request.render('xpiva_business_centre.odoo-registration')